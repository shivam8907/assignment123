// program to print "%d" on the screen
#include<stdio.h>
int main()
{
    int number;
    printf("  %d   ");
   
    return 0;
}
