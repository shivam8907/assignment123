#include<stdio.h>
int main()
{
    printf("  \"ineuron\"  ");
    return 0;

}