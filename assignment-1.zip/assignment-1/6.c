//program to print the name of the user in double quotes
#include<stdio.h>
int main()
{
    printf("  \"Hello, Amit Kumar\"  ");
    return 0;
}