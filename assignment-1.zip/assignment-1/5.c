/* program to calculate lenth of the string using printf*/
#include<stdio.h>
int main()
{
    int x = printf("shivam");
    printf("%d",x);
    return 0;
}