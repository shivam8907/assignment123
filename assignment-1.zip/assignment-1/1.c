//program to print hello students
#include<stdio.h>
int main()
{
    printf("Hello Students");

    return 0;
}