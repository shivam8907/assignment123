// program to take date as an input and convert the date format and display the resutl
#include<stdio.h>
int main()
{
    int dd, mm, yyyy;
    printf("Enter date\n");
    scanf("%d,&dd");
    printf("Enter month");
    scanf("%d", &mm);
    printf("Enter year");
    scanf("%d",&yyyy);
    printf("you have entered %d %d %d", dd,mm,yyyy);
    printf("you have entered %d -%d -%d", dd,mm,yyyy);
    printf("you have entered %d %d %d", dd,mm,yyyy);
return 0;
}
