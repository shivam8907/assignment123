//program for find output of the code
#include<stdio.h>
int main()
{
    int x = printf("ineuron");
    printf("%d",x);
    return 0;
}