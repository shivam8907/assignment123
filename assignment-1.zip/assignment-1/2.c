// program to print hello in the first line and student in the next line
#include<stdio.h>
int main()
    {
        printf("Hello \n");
        printf("Students");

return 0;
    }