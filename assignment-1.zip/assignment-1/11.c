#include<stdio.h>
int main()
{
int hours, minute;
printf("Enter hours=");
scanf("%d", &hours);
printf("enter minute");
scanf("%d", &minute);
printf("Entered hours  %d",hours);
printf("entered minute %d",minute);
return 0;
}
